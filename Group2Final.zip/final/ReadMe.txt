Modern versions of browser should be compatible. Works with both mobile and desktop versions.

1. Extract the zip file.
2. Run index.html file.

